import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import cvxpy as cp
from scipy.fftpack import dct, idct, fft
from scipy.interpolate import interp1d
from tkinter import filedialog
import tkinter as tk
from tkinter import messagebox
import os

def random_mask(N, keep_ratio, seed=42):
    np.random.seed(seed)
    num_keep = int(N * keep_ratio)
    indices = np.sort(np.random.choice(N, num_keep, replace=False))
    mask = np.zeros(N, dtype=bool)
    mask[indices] = True
    return mask

def dct_l1_reconstruction(y_partial, mask):
    N = len(y_partial)
    D = dct(np.identity(N), norm='ortho')
    A = D[mask]
    y = y_partial[mask]

    alpha = cp.Variable(N)
    objective = cp.Minimize(cp.norm1(alpha))
    constraints = [A @ alpha == y]
    prob = cp.Problem(objective, constraints)
    prob.solve(verbose=False)

    x_hat = idct(alpha.value, norm='ortho')
    return x_hat

def add_high_freq_noise(signal, fs=1000, noise_freq=200, noise_amplitude=0.2):
    t = np.arange(len(signal)) / fs
    high_freq = noise_amplitude * np.sin(2 * np.pi * noise_freq * t)
    noisy_signal = signal + high_freq
    return noisy_signal

def interpolate_methods(signal, mask, method="linear"):
    x_known = np.where(mask)[0]
    y_known = signal[mask]

    interp_func = interp1d(x_known, y_known, kind=method, fill_value="extrapolate")
    return interp_func(np.arange(len(signal)))

def run_reconstruction(fs, noise_amp, keep_ratio, use_linear, use_spline):
    root = tk.Tk()
    root.withdraw()
    path = filedialog.askopenfilename(
        filetypes=[("CSV files", "*.csv")],
        title="元信号CSVファイルを選んでください"
    )

    if not path:
        print("キャンセルされました")
        return

    df = pd.read_csv(path)
    df.columns = df.columns.str.strip()
    if "value" not in df.columns:
        print("エラー: 'value'列がありません。")
        return

    full_signal = df["value"].to_numpy()
    N = len(full_signal)
    mask = random_mask(N, keep_ratio=keep_ratio, seed=42)

    full_signal_noisy = add_high_freq_noise(full_signal, fs=fs, noise_freq=20, noise_amplitude=1)
    gaussiannoise = noise_amp * np.random.randn(len(full_signal))
    full_signal_noisy = full_signal + gaussiannoise

    y_partial = full_signal_noisy.copy()
    y_partial[~mask] = np.nan

    print("Reconstructing with DCT+L1...")
    y_reconstructed = dct_l1_reconstruction(y_partial, mask)

    # 補間
    y_linear = interpolate_methods(full_signal_noisy, mask, method="linear") if use_linear else None
    y_spline = interpolate_methods(full_signal_noisy, mask, method="cubic") if use_spline else None

    #圧縮センシング結果メッセージ表示
    mse_re = np.mean((full_signal_noisy - y_reconstructed)**2)
    mse_li = np.mean((full_signal_noisy - y_linear)**2)
    mse_sp = np.mean((full_signal_noisy - y_spline) ** 2)
    obs_indices = np.where(mask)[0]
    print(f"Total Points: {N} , Keep Points: {len(obs_indices)} , Keep Ratio: {keep_ratio * 100:.1f}%")
    print(f"\n Complete! \nMSE(org vs rec): {mse_re:.6f} \nMSE(org vs linear): {mse_li:.6f} \nMSE(org vs spline): {mse_sp:.6f}")

    # プロット
    plt.figure(figsize=(12, 6))
    plt.plot(full_signal_noisy, label="Noisy", color='blue', linewidth=1)
    plt.scatter(np.where(mask)[0], full_signal_noisy[mask], label="Sampled", color='red', s=10, zorder=3)
    plt.plot(y_reconstructed, label="DCT+L1 Reconstructed", color='green', linestyle='--', linewidth=1)
    if use_linear:
        plt.plot(y_linear, label="Linear Interpolation", linestyle=':', color='orange',linewidth=2)
    if use_spline:
        plt.plot(y_spline, label="Spline Interpolation", linestyle='-.', color='purple',linewidth=2)
    plt.plot(full_signal, label="Original", linestyle='dotted', color='black')
    plt.title("Signal Reconstruction Comparison")
    plt.xlabel("Sample Index")
    plt.ylabel("Value")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    # 保存
    save_path = filedialog.asksaveasfilename(
        defaultextension=".csv",
        filetypes=[("CSV files", "*.csv")],
        title="再構成データの保存先を指定してください"
    )
    if save_path:
        root, ext = os.path.splitext(save_path)
        save_path2 = root + "_sampled_point" + ext

        out_df = pd.DataFrame({
            "original": full_signal,
            "noisy": full_signal_noisy,
            "reconstructed_DCT": y_reconstructed,
        })
        if use_linear:
            out_df["linear_interp"] = y_linear
        if use_spline:
            out_df["spline_interp"] = y_spline
        out_df.to_csv(save_path, index=False)

        out_df2 = pd.DataFrame({
            "sampled": full_signal_noisy[mask],
        })
        out_df2.to_csv(save_path2, index=False)

        print(f"保存しました: {save_path}, {save_path2}")
        exit()
    else:
        print("保存はキャンセルされました")
        exit()

def launch_gui():
    def on_run():
        try:
            fs = int(entry_fs.get())
            noise_amp = float(entry_noise.get())
            keep_ratio = float(entry_keep.get())
            if not (0 < keep_ratio <= 1):
                raise ValueError("保持率は 0～1 の間で指定してください")
            use_linear = var_linear.get()
            use_spline = var_spline.get()
            root.destroy()
            run_reconstruction(fs, noise_amp, keep_ratio, use_linear, use_spline)
        except Exception as e:
            messagebox.showerror("入力エラー", str(e))

    root = tk.Tk()
    root.title("圧縮センシングデモ")

    tk.Label(root, text="サンプリング周波数 (Hz)").grid(row=0, column=0, sticky='e')
    entry_fs = tk.Entry(root)
    entry_fs.insert(0, "1000")
    entry_fs.grid(row=0, column=1)

    tk.Label(root, text="ガウスノイズ振幅").grid(row=1, column=0, sticky='e')
    entry_noise = tk.Entry(root)
    entry_noise.insert(0, "0.2")
    entry_noise.grid(row=1, column=1)

    tk.Label(root, text="データ保持率 (0~1)").grid(row=2, column=0, sticky='e')
    entry_keep = tk.Entry(root)
    entry_keep.insert(0, "0.3")
    entry_keep.grid(row=2, column=1)

    var_linear = tk.BooleanVar()
    var_spline = tk.BooleanVar()

    tk.Checkbutton(root, text="線形補間と比較", variable=var_linear).grid(row=6, column=0, columnspan=2, sticky='w')
    tk.Checkbutton(root, text="スプライン補間と比較", variable=var_spline).grid(row=7, column=0, columnspan=2, sticky='w')

    tk.Button(root, text="実行", command=on_run).grid(row=8, column=0, columnspan=2, pady=10)
    root.mainloop()

if __name__ == "__main__":
    launch_gui()
